BAZAR MELA ADMIN PANEL — SETUP

1) Open index.html and replace PASTE_YOUR_FIREBASE_API_KEY with the Web API key from:
   Firebase Console > Project settings > General > Your apps > SDK setup and configuration.
   Keep the other Firebase config values as shown only if they match your project.

2) Firebase Authentication:
   Build > Authentication > Sign-in method > Email/Password = Enabled.
   Create the admin user under Authentication > Users.

3) Secure admin authorization:
   Copy that admin user's UID from Authentication > Users.
   Firestore Database > Data > Start collection:
     Collection ID: admins
     Document ID: (paste the admin UID)
     Field: active | Type: boolean | Value: true
   Do NOT let the public website create or edit documents in admins.

4) Firestore Rules:
   Open Firestore Database > Rules, replace the rules with firestore.rules contents, then Publish.
   IMPORTANT: These rules are a starter for this exact schema. Review them before launch.
   Customer order form must write customerUid as the signed-in customer's Firebase Auth UID.

5) Hosting:
   Create a separate GitHub repository, e.g. bazar-mela-admin.
   Upload index.html to the repository root and enable GitHub Pages (Deploy from branch / main / root).
   Admin URL will look like https://YOUR-USERNAME.github.io/bazar-mela-admin/

6) Product images:
   Billing/Storage is not configured yet, so use public HTTPS image URLs for now.
   Never put passwords, private service-account keys, or payment secrets in this HTML.

Collections used:
  admins/{uid}
  categories/{categoryId}: name, active
  products/{productId}: name, price, stock, category, imageUrl, description, active
  orders/{orderId}: customerUid, customerName, phone, total, status, createdAt

The customer website must use the same collections and compatible fields.
